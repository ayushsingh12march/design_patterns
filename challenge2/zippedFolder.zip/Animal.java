package challenge2;

public interface Animal {
    void eat();

    void run();

    void swim();
}
