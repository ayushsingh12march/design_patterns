package challenge2.modified.Eating;

public interface EatBehavior {
    void eat();
}
