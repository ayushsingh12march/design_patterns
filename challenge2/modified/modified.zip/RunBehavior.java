package challenge2.modified.Running;

public interface RunBehavior {
    void run();

    boolean canRun();
}
