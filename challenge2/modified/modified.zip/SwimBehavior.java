package challenge2.modified.Swimming;

public interface SwimBehavior {
    void swim();

    boolean canSwim();
}
